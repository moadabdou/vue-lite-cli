module.exports = {
    use : [
        "vue-router"
    ], 
    sources : {  
        src : 'src', 
        app : "app" , 
        mixins : "mixins", 
        components:"components", 
        views : "views", 
        routes : "routes"      
    }
}
