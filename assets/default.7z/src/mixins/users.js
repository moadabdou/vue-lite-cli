vl={
    props : {
        title : String
    }
} //you dont need to write () here bcz mixins dont need any html file