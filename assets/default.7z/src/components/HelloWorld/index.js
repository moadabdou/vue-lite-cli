vl={
    props: {
        msg : String
    }, 
    data : function (){
        return {
            name : "Vue Lite"
        }
    }
}()