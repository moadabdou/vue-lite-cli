vl={
    data : function (){
        return {
            title : "you are in home page"
        }
    }
}()