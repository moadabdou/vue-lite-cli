let vm = new Vue({
    el : "#app" , 
    data : {
        name : "moad abdou"
    }, 

    
    router //from routes/index.js
})