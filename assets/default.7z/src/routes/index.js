const routes = [
    HOME,  //home route setting from [home.js]
    {path : '/about' , component : about} //about components is exists on views folder
]

const router =  new VueRouter({
    routes
})
//this is a global code 
//router will be used in app/index.js