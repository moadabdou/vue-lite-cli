const HOME = {path : '/' , component : home}
